CarvaoControl - Versão Single-File (compacta)

O que há nesta pasta:
- Um executável único: CarvaoControl.exe (self-contained, single-file).

Como executar:
1. Baixe o arquivo `CarvaoControl.exe` desta pasta `release`.
2. Dê dois cliques para abrir. Não é necessário instalar .NET.

Observações:
- Pode existir uma subpasta `Resources/` com ícones/recursos. Normalmente você só precisa do `CarvaoControl.exe`.
- Em alguns ambientes, o aplicativo pode extrair arquivos temporários ao iniciar (comportamento esperado do modo single-file).

Suporte:
email: mateusparaisolog@gmail.com